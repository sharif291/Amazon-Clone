import bcrypt from "bcryptjs";
const data = {
  users: [
    {
      name: "Sharif",
      email: "sharif@halcyonbd.com",
      password: bcrypt.hashSync("1234", 8),
      isAdmin: true,
    },
    {
      name: "Unknown",
      email: "Unknown@halcyonbd.com",
      password: bcrypt.hashSync("1234", 8),
      isAdmin: false,
    },
  ],
  products: [
    {
      name: "Nike Slim Pant",
      category: "Shirts",
      image: "/images/p1.jpg",
      price: 120,
      countInStock: 10,
      brand: "Pants",
      rating: 4.5,
      numReviews: 10,
      description: "High Quality Product",
    },
    {
      name: "Nike Steach Pant",
      category: "Pants",
      image: "/images/p3.jpg",
      price: 80,
      countInStock: 0,
      brand: "Nike",
      rating: 5,
      numReviews: 20,
      description: "High Quality Product",
    },
    {
      name: "Adidas Slim Pant",
      category: "Pants",
      image: "/images/p3.jpg",
      price: 100,
      countInStock: 10,
      brand: "Adidas",
      rating: 3.5,
      numReviews: 10,
      description: "High Quality Product",
    },
    {
      name: "Nike Slim Shirt",
      category: "Shirts",
      image: "/images/p4.jpg",
      price: 120,
      countInStock: 10,
      brand: "Nike",
      rating: 4.5,
      numReviews: 10,
      description: "High Quality Product",
    },
  ],
};

export default data;
